For the ADRB2-alprenolol system, starting structure (alp_bin_conf.gro) and topology files for the MD run are provided.
32 representative structures were extracted from the MD trajectory to initialise each walker. The protein coordinates are provided as pdb files.
Plumed input file to run MW-MetaD with A100 CV is also provided (plumed.dat).



